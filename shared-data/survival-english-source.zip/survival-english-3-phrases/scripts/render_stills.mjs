import { mkdirSync, readFileSync } from "node:fs";
import { spawnSync } from "node:child_process";

const timeline = JSON.parse(readFileSync("src/data/timeline.json", "utf8"));
mkdirSync("verification", { recursive: true });

for (const id of [1, 3, 6, 9]) {
  const beat = timeline.beats[id - 1];
  // Capture the pause state, hollow outline, full rain, and the completed comparison.
  const fraction = id === 3 ? 0.92 : 0.76;
  const frame = beat.startFrame + Math.floor(beat.durationInFrames * fraction);
  const args = [
    "remotion",
    "still",
    "src/index.ts",
    "SurvivalEnglish3Phrases",
    `verification/beat-${id}.png`,
    `--frame=${frame}`,
    "--scale=1",
    "--log=warn",
    ...process.argv.slice(2),
  ];
  const result = spawnSync(
    process.platform === "win32" ? "npx.cmd" : "npx",
    args,
    { stdio: "inherit" },
  );
  if (result.status !== 0) process.exit(result.status ?? 1);
}
