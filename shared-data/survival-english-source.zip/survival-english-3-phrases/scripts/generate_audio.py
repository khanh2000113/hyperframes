"""Synthesize the lesson, measure its frame-accurate timeline and create the sound bed."""
import argparse
import asyncio
import json
import math
import os
from pathlib import Path
import re
import subprocess
import tempfile
import wave

import edge_tts
import numpy as np
from aiohttp import ClientError
from edge_tts.exceptions import EdgeTTSException

ROOT = Path(__file__).resolve().parents[1]
FPS, RATE = 30, 48000
VOICES = [
    ("vi-VN-NamMinhNeural", "+10%"),
    ("en-US-AndrewNeural", "+0%"),
    ("en-US-BrianNeural", "+0%"),
]
SCRIPT = [
    [(0, "Đang nói chuyện với Tây mà tự dưng... đứng hình?")],
    [(0, "Đừng im re! Xài ngay 3 câu cứu mạng này.")],
    [(0, "Một. Quên sạch từ? Nói:"), (1, "My mind went blank.")],
    [(1, "Sorry... my mind went blank!")],
    [(0, "Hai. Bí tên đồ vật? Hỏi:"), (1, "What do you call...?")],
    [(1, "What do you call... the thing for rain?")],
    [(2, "Oh, an umbrella!")],
    [(0, "Ba. Cần chút thời gian nghĩ? Nói:"), (1, "Give me a second.")],
    [(0, "Nghe tự nhiên hơn hẳn kiểu 'À... ừm...'.")],
    [(0, "Nhớ 3 phao cứu sinh này:")],
    [(0, "Lưu lại để lần sau khỏi sợ... nếu có lỡ...")],
]
CUES = [
    [("record_scratch", 0, .33), ("error_beep", 8, .22)],
    [("crumble", 0, .28), ("pop", 5, .23), ("pop_high", 10, .21), ("pop_high", 15, .19, 1.13)],
    [("whoosh", 0, .23), ("vacuum", "phrase-9", .31), ("pop", "phrase", .22)],
    [("click", 0, .23), ("ding", 13, .20)],
    [("snap", 0, .25), ("boing", "phrase", .23)],
    [("pop", 0, .24), ("rain_short", 6, .19)],
    [("umbrella_pop", 0, .31), ("ding", 9, .24)],
    [("whoosh", 0, .26), ("tick_tock", 6, .21)],
    [("buzzer", 0, .23), ("chime", 17, .24)],
    [("pop", 0, .30), ("pop_high", 18, .26), ("pop_high", 36, .23, 1.15)],
    [("reverse_whoosh", "end-14", .32)],
]


def ffmpeg(*args):
    return subprocess.check_output(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", *map(str, args)])


def read_pcm(path, filters, rate=RATE):
    data = ffmpeg("-i", path, "-af", filters, "-ac", 1, "-ar", rate, "-f", "f32le", "-")
    return np.frombuffer(data, dtype="<f4").copy()


def write_wav(path, signal):
    with wave.open(str(path), "wb") as output:
        output.setparams((1, 2, RATE, 0, "NONE", "not compressed"))
        output.writeframes(np.asarray(np.clip(signal, -1, 1) * 32767, dtype="<i2").tobytes())


class SpeechServiceError(RuntimeError):
    """Edge TTS could not synthesize a line."""


async def speak(text, voice_index, path):
    voice, speed = VOICES[voice_index]
    session = edge_tts.Communicate(text, voice, rate=speed, boundary="WordBoundary",
                                   proxy=os.environ.get("EDGE_TTS_PROXY"))
    words = []
    with path.open("wb") as media:
        try:
            async for chunk in session.stream():
                if chunk["type"] == "audio":
                    media.write(chunk["data"])
                elif chunk["type"] == "WordBoundary":
                    words.append((chunk["text"], chunk["offset"] / 1e7))
        except (ClientError, EdgeTTSException, TimeoutError) as error:
            raise SpeechServiceError(
                f"Edge TTS failed for {voice} while synthesizing {text!r}. "
                f"Check your internet connection and EDGE_TTS_PROXY if required. "
                f"{type(error).__name__}: {error}"
            ) from error
    return words


def limit_pauses(pcm, words):
    # Keep the edges of natural internal gaps, limiting quiet runs to 120 ms.
    step = RATE // 100
    chunks = pcm[:len(pcm)//step*step].reshape(-1, step)
    quiet = np.max(np.abs(chunks), axis=1) < .009
    switches = np.flatnonzero(np.diff(np.r_[False, quiet, False]))
    cuts = [(a*step+6*step, b*step-6*step) for a, b in switches.reshape(-1, 2) if b-a > 13]
    pieces, cursor = [], 0
    for a, b in cuts:
        pieces.append(pcm[cursor:a])
        cursor = b
    pieces.append(pcm[cursor:])
    pcm = np.concatenate(pieces)
    return pcm, [
        (word, max(0, min(len(pcm)/RATE, position -
                         sum(max(0, min(position*RATE, b)-a) / RATE for a, b in cuts))))
        for word, position in words
    ]


def trim(path, words, text):
    edge = "silenceremove=start_periods=1:start_duration=0.016:start_threshold=-45dB:start_silence=0.012"
    pcm = read_pcm(path, f"{edge},areverse,{edge},areverse")
    if not pcm.size:
        raise RuntimeError(f"Empty Edge TTS clip for {text}")
    if words:
        base = words[0][1]
        words = [(word, time - base) for word, time in words]
    pcm, words = limit_pauses(pcm, words)
    pcm *= min(4, .75 / max(.001, np.max(np.abs(pcm))))
    fade = min(160, len(pcm)//2)
    pcm[:fade] *= np.linspace(0, 1, fade)
    pcm[-fade:] *= np.linspace(1, 0, fade)
    if not words:
        tokens = re.findall(r"[\w’']+", text)
        weights = [max(2, len(token)) for token in tokens]
        starts = np.r_[0, np.cumsum(weights)[:-1]] / sum(weights) * len(pcm) / RATE
        return pcm, list(zip(tokens, starts))
    return pcm, words


async def build_voice():
    with tempfile.TemporaryDirectory() as directory:
        raw = Path(directory)
        async def build_part(beat, part, voice, line):
            path = raw / f"{beat}-{part}.mp3"
            words = await speak(line, voice, path)
            return await asyncio.to_thread(trim, path, words, line)

        parts = []
        for beat, lines in enumerate(SCRIPT, 1):
            parts.append([await build_part(beat, i, voice, line) for i, (voice, line) in enumerate(lines)])
        return parts


def make_timeline(parts):
    measured = [sum(len(pcm) for pcm, _ in beat) / RATE for beat in parts]
    # Favor compact cuts, allocating the available breathing room to transitions.
    pads = [5, 5, 5, 6, 5, 6, 7, 5, 6, 10, 10]
    gaps = [1 if len(beat) == 2 else 0 for beat in parts]
    speed = min(1., sum(measured) / max(1, (824 - sum(pads) - sum(gaps) - 12) / FPS))
    if sum(measured) > (870 - sum(pads) - sum(gaps) - 12) / FPS:
        speed = sum(measured) / ((843 - sum(pads) - sum(gaps) - 12) / FPS)

    beats, start = [], 0
    with tempfile.TemporaryDirectory() as directory:
        intermediate = Path(directory) / "line.wav"
        for index, (lines, pad, gap) in enumerate(zip(parts, pads, gaps), 1):
            segments, offset = [], 0
            for i, (pcm, words) in enumerate(lines):
                if abs(speed - 1) > .002:
                    write_wav(intermediate, pcm)
                    pcm = read_pcm(intermediate, f"atempo={speed:.6f}")
                    words = [(word, time / speed) for word, time in words]
                    # Slowing the line can stretch already-trimmed pauses.
                    if speed < 1:
                        pcm, words = limit_pauses(pcm, words)
                duration = math.ceil(len(pcm) / RATE * FPS)
                file = f"vo/beat_{index:02d}_{i+1}.wav"
                write_wav(ROOT / "public" / file, pcm)
                segments.append(dict(file=file, startFrame=offset, durationInFrames=duration,
                                     durationSeconds=len(pcm)/RATE,
                                     words=[dict(text=w, frame=min(duration-1, round(t*FPS))) for w,t in words]))
                offset += duration + (gap if i == 0 else 0)
            phase = (segments[-1]["startFrame"] if len(segments) > 1 else 0)
            length = offset + pad
            cues = []
            for name, frame, gain, *pitch in CUES[index-1]:
                if isinstance(frame, str):
                    frame = {"phrase-9": phase-9, "phrase": phase, "end-14": length-14}[frame]
                cues.append(dict(file=f"sfx/{name}.wav", frame=max(0, min(length-1, frame)),
                                 volume=gain, rate=pitch[0] if pitch else 1))
            beats.append(dict(id=index, startFrame=start, durationInFrames=length,
                              durationSeconds=length/FPS, segments=segments, cues=cues))
            start += length
    return dict(fps=FPS, durationInFrames=start, durationSeconds=start/FPS,
                voiceProvider="edge-tts", beats=beats)


def make_effects(duration):
    rng = np.random.default_rng(151)
    def time(seconds):
        return np.arange(round(seconds*RATE))/RATE

    def sweep(t, low, high):
        return np.sin(2*np.pi*(low*t+(high-low)*t*t/(2*t[-1])))

    def noise(t, width=23):
        return np.convolve(rng.normal(size=t.size), np.hanning(width)/(width/2), "same")

    def envelope(t, attack=.025, release=.06):
        return np.minimum(1, t/attack)*np.clip((t[-1]-t)/release, 0, 1)

    def tone(seconds, freq, decay):
        t = time(seconds)
        return envelope(t, .004)*np.exp(-t/decay)*(sweep(t, freq, .94*freq)+.25*sweep(t, 2*freq, 1.9*freq))

    effects = {}
    t = time(.37)
    effects["record_scratch"] = envelope(t)*(.62*noise(t, 41)+.38*sweep(t, 680, 92))*np.sin(63*t)**2
    effects["error_beep"] = tone(.18, 247, .12)
    t = time(.46)
    effects["crumble"] = noise(t, 17)*envelope(t)*np.exp(-5*t)*np.sin(73*t)**4
    effects["pop"] = tone(.16, 488, .055)
    effects["pop_high"] = tone(.16, 720, .06)
    t = time(.47)
    effects["whoosh"] = envelope(t, .15, .28)*(noise(t, 65)+.13*sweep(t, 140, 85))
    effects["reverse_whoosh"] = effects["whoosh"][::-1]
    t = time(.43)
    effects["vacuum"] = envelope(t, .03, .16)*(.65*noise(t, 49)+.25*sweep(t, 900, 110))
    effects["click"] = tone(.07, 950, .015)
    effects["ding"] = tone(.54, 1047, .19)
    t = time(.14)
    effects["snap"] = envelope(t, .006, .1)*noise(t, 13)
    t = time(.42)
    effects["boing"] = envelope(t, .01, .16)*np.exp(-3*t)*np.sin(2*np.pi*262*t+4*np.sin(32*t))
    t = time(2.55)
    effects["rain_short"] = envelope(t, .15, .34)*noise(t, 19)
    t = time(.29)
    effects["umbrella_pop"] = .55*envelope(t, .025, .14)*noise(t, 41) + tone(.29, 375, .07)
    effects["tick_tock"] = np.zeros(round(2.3*RATE))
    for k in range(5):
        click = tone(.07, 810 if k%2 else 515, .016)
        effects["tick_tock"][k*21600:k*21600+len(click)] += click
    effects["buzzer"] = tone(.32, 148, .12)+.34*tone(.32, 154, .13)
    effects["chime"] = tone(.54, 784, .17) + np.r_[np.zeros(3840), tone(.46, 1175, .18)]

    for name, pcm in effects.items():
        write_wav(ROOT / "public/sfx" / f"{name}.wav", .68 * pcm / max(.01, np.max(np.abs(pcm))))

    bed = np.zeros(round(duration*RATE))
    notes = [48, 55, 60, 55, 50, 57, 62, 57, 45, 52, 60, 52, 43, 55, 59, 55]
    for k in range(math.ceil(duration * 115/60*2)):
        note = notes[(k//2)%len(notes)] + (12 if k%2 else 0)
        freq = 440*2**((note-69)/12)
        t = time(.42 if k%2==0 else .20)
        pcm = .69*envelope(t, .01, .11)*np.exp(-8*t)*(
            np.sin(2*np.pi*freq*t)+.20*np.exp(-12*t)*np.sin(2*np.pi*freq*3.99*t))
        begin = round(k*RATE*60/115/2)
        end = min(len(bed), begin+len(pcm))
        bed[begin:end] += pcm[:end-begin]*(.45 if k%2 else 1)
    write_wav(ROOT / "public/sfx/bg_bed.wav", bed)


def main():
    argparse.ArgumentParser(description=__doc__).parse_args()
    try:
        parts = asyncio.run(build_voice())
    except SpeechServiceError as error:
        raise SystemExit(str(error)) from None
    for directory in ("public/vo", "public/sfx", "src/data"):
        (ROOT / directory).mkdir(parents=True, exist_ok=True)
    timeline = make_timeline(parts)
    make_effects(timeline["durationSeconds"])
    path = ROOT / "src/data/timeline.json"
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(timeline, ensure_ascii=False, indent=2)+"\n", encoding="utf8")
    temporary.replace(path)
    print(f"{timeline['durationInFrames']} frames / {timeline['durationSeconds']:.3f}s ({timeline['voiceProvider']})")


if __name__ == "__main__":
    main()
