import { Config } from "@remotion/cli/config";

Config.setVideoImageFormat("jpeg");
Config.setPixelFormat("yuv420p");
Config.setOverwriteOutput(true);

// The installed Google Fonts build exposes its base loader through CommonJS.
Config.overrideWebpackConfig((config) => ({
  ...config,
  resolve: {
    ...config.resolve,
    alias: {
      ...config.resolve?.alias,
      "@remotion/google-fonts/base$":
        require.resolve("@remotion/google-fonts/base"),
    },
  },
}));
