# Render verification

Each PNG was captured at 1080 × 1920 with Remotion still. Visual inspection confirmed that the main text is readable and separated from the stage and progress pill. The comparison labels and hook glyphs are part of the SVG stage. The reserved bottom area contains only the shared paper background.

Pixel bounds below use the rows showing foreground against the paper grain. All reported ranges fall inside the progress region (80–259), the stage (280–1179) or the main typography region (1200–1539).

| Beat | Frame | Foreground rows |
| ---: | ---: | :--- |
| 1 | 60 | 280–1179, 1284–1421 |
| 3 | 243 | 125–206, 280–1179, 1255–1348, 1382–1486 |
| 6 | 438 | 125–206, 280–1179, 1267–1356, 1370–1492 |
| 9 | 656 | 125–206, 280–1179, 1311–1428 |

The timeline has 11 contiguous beats and 811 frames. Each narration asset matches its measured timeline duration. All 17 sound effects and the music bed are present.

FFprobe confirmed H.264 at 1080×1920, 30 fps, 811 frames, and stereo AAC at 48 kHz. The picture lasts 27.033 seconds and the MP4 container lasts 27.051 seconds including AAC padding. The decoded audio sample peak was −5.2 dBFS.

The first and final decoded frames were compared at 360×640. Their mean absolute RGB channel difference was 0.36 out of 255, consistent with a visually matched loop across the H.264 encode. A clean extraction of the source ZIP passed `npm ci --offline` and `npm run typecheck`.
