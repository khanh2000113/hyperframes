# Survival English · 3 Phrases

An editable Remotion project with 11 beats at **1080×1920**, **30 fps**. The included narration and effects produce **811 frames / 27.033 seconds**. The video features Vietnamese narration, English examples, and a separate English reply voice in the umbrella scene.

## Render

Use Node 22+, npm, and a supported Chrome or Chromium installation.

```sh
npm ci
npm run typecheck
npm run studio
npm run render
npm run stills
```

The MP4 is written to `out/survival_english_3_phrases.mp4` as H.264 (CRF 18, yuv420p) with AAC audio. The four full-resolution stills go to `verification/`. To use a system browser, append `-- --browser-executable=/path/to/chromium` to the render or stills command.

The Remotion entry point is `src/index.ts`. Select `SurvivalEnglish3Phrases` in a video-shotcraft workflow that accepts Remotion projects. No video-shotcraft version or import schema was supplied, so dedicated importer support has not been verified. To place the project in the HyperFrames monorepo, copy the ZIP's top-level folder to `examples/survival-english-3-phrases/` and run the commands from that directory.

## Regenerate audio

The included WAVs and timeline are enough to render without contacting a speech or font service. To regenerate them, use Python 3.12+, FFmpeg, and a connection to the Edge TTS service.

```sh
python -m pip install -r requirements.txt
python scripts/generate_audio.py
```

Edge TTS uses NamMinh at +10%, Andrew at +0%, and Brian at +0%. Set `EDGE_TTS_PROXY` if your network requires an explicit proxy supported by edge-tts. The script applies FFmpeg silence trimming to each line, shortens internal pauses, writes the exact PCM durations and 30 fps segment offsets, and regenerates all 17 effects and the 115 BPM bed. Remotion plays the bed from Beat 2 at −22 dB. Kinetic text uses Edge word boundaries when available.

The bundled WAVs and the previously rendered MP4 are from the original Piper render. Run the commands above before rendering to replace the bundled narration and timeline with Edge TTS output. The generator exits with an error if the Edge TTS service is unavailable.

The model archives used for this render are from the [Sherpa ONNX tts-models release](https://github.com/k2-fsa/sherpa-onnx/releases/tag/tts-models). The voice dataset credits are [VAIS 1000 (CC BY 4.0)](https://ieee-dataport.org/documents/vais-1000-vietnamese-speech-synthesis-corpus), [RyanSpeech (CC BY-NC-SA 4.0)](https://www.kaggle.com/datasets/roholazandie/ryanspeech), and [Nabu Casa Joe (CC0)](https://github.com/NabuCasa/voice-datasets). Be Vietnam Pro is loaded through Remotion Google Fonts using bundled WOFF2 files and is distributed with its SIL Open Font License in `public/fonts/OFL.txt`.

## Editing

- `scripts/generate_audio.py` contains the script, voice choices, procedural sound design and beat timing.
- `src/data/timeline.json` is generated from trimmed WAVs and drives both the composition duration and cue placement.
- `src/Lesson.tsx` places the progress pill, kinetic typography and audio layers.
- `src/components/Stage.tsx` and `src/components/Stickman.tsx` draw the animated SVG stage and characters.
- `public/` contains all audio, font and grain assets used for rendering.
