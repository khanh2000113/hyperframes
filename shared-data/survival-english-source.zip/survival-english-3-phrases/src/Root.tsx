import React from "react";
import { Composition } from "remotion";
import { SurvivalEnglish3Phrases } from "./Lesson";
import timeline from "./data/timeline.json";

export const Root: React.FC = () => (
  <Composition
    id="SurvivalEnglish3Phrases"
    component={SurvivalEnglish3Phrases}
    width={1080}
    height={1920}
    fps={timeline.fps}
    durationInFrames={timeline.durationInFrames}
  />
);
