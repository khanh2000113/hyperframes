import React from "react";
import { spring } from "remotion";
import { Stickman } from "./Stickman";

export const INK = "#1D1D1F";
export const RED = "#E63946";
export const BLUE = "#2563EB";
export const AMBER = "#D97706";
export const GREEN = "#059669";
export const PAPER = "#F5F0E6";
const WHITE = "#FFFDF8";
export const TINTS: Record<string, string> = {
  [RED]: "#FCE4DC",
  [BLUE]: "#E1EAFF",
  [AMBER]: "#FFE9C8",
  [GREEN]: "#DCF2E5",
};
const palette = [BLUE, AMBER, GREEN];
export const pop = (frame: number) =>
  spring({ fps: 30, frame, config: { damping: 14, stiffness: 180 } });
export const clamp = (x: number) => Math.max(0, Math.min(1, x));
export const ease = (x: number) => clamp(x) ** 2 * (3 - 2 * clamp(x));
const mix = (a: number, b: number, t: number) => a + (b - a) * t;
const phraseList = [
  "My mind went blank",
  "What do you call...?",
  "Give me a second",
];

const medallion = (color: string, kind: number) => (
  <g
    fill="none"
    stroke={color}
    strokeWidth="5.5"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    {kind === 0 && (
      <path d="M-22 -13Q-22 -23 -12 -23H13Q23 -23 23 -13V5Q23 15 13 15H-2L-17 24V15Q-22 14 -22 7Z" />
    )}
    {kind === 1 && (
      <text
        x="0"
        y="22"
        textAnchor="middle"
        stroke="none"
        fill={color}
        fontSize="58"
        fontWeight="900"
      >
        ?
      </text>
    )}
    {kind === 2 && (
      <>
        <circle cy="3" r="20" />
        <path d="M0 -17v-11m-7 0H7M0 3l7 -10" />
      </>
    )}
  </g>
);

const Spark: React.FC<{
  x: number;
  y: number;
  color: string;
  scale?: number;
}> = ({ x, y, color, scale = 1 }) => (
  <path
    d="M0 -18 Q3 -3 18 0 Q3 3 0 18 Q-3 3 -18 0 Q-3 -3 0 -18Z"
    transform={`translate(${x} ${y}) scale(${scale})`}
    fill={color}
  />
);

export const Bookmark: React.FC<{ color?: string }> = ({ color = GREEN }) => (
  <path
    d="M-17 -23H17Q22 -23 22 -17V26L0 12 -22 26V-17Q-22 -23 -17 -23Z"
    fill="none"
    stroke={color}
    strokeWidth="6"
    strokeLinejoin="round"
  />
);

const bubble =
  "M42 2H322Q359 2 359 39V111Q359 149 322 149H135L99 181 106 149H42Q5 149 5 111V39Q5 2 42 2Z";
const Hook: React.FC<{ f: number; opacity?: number }> = ({
  f,
  opacity = 1,
}) => {
  const shake = f < 14 ? Math.sin(f * 2) * 9 * (1 - f / 14) : 0;
  return (
    <g opacity={opacity} transform={`translate(${shake} 0)`}>
      <g transform={`translate(84 ${132 + Math.sin(f / 7) * 5})`}>
        <path d={bubble} transform="translate(0 11)" fill="#E9CCBB" />
        <path
          d={bubble}
          fill={WHITE}
          stroke={INK}
          strokeWidth="7"
          strokeLinejoin="round"
        />
        <clipPath id="hook-bubble-text">
          <rect x="25" y="26" width="305" height="100" rx="20" />
        </clipPath>
        <g
          clipPath="url(#hook-bubble-text)"
          fontSize="43"
          fontWeight="900"
          fill={INK}
        >
          <text x={24 - ((f * 14) % 228)} y="66">
            !?%# @&amp;! ?!%# @&amp;!
          </text>
          <text x={18 - ((f * 9) % 207)} y="115" fill={RED}>
            #&amp;?! @$ #&amp;?! @$ #&amp;
          </text>
        </g>
      </g>
      <Spark
        x={505}
        y={232}
        color={RED}
        scale={0.83 + 0.14 * Math.sin(f / 4)}
      />
      <Stickman
        x={270}
        y={399}
        scale={1.25}
        pose="idle"
        accentColor={RED}
        frame={f}
      />
      <Stickman
        x={690}
        y={399}
        scale={1.25}
        pose="frozen_404"
        accentColor={RED}
        frame={f}
        flipX
      />
      <path
        d="M797 367l24 -31m-6 59 42 -10"
        stroke={RED}
        strokeWidth="8"
        strokeLinecap="round"
      />
    </g>
  );
};

const Crash: React.FC<{ f: number }> = ({ f }) => {
  const fly = ease(f / 22);
  return (
    <>
      <g opacity={1 - fly}>
        {Array.from({ length: 14 }, (_, i) => {
          const angle = i * 2.399;
          const r = (48 + i * 7) * (1 + 2.3 * fly);
          return (
            <path
              key={i}
              d="M-19 8 3 -22 21 18Z"
              fill={i % 3 ? RED : INK}
              transform={`translate(${480 + Math.cos(angle) * r} ${340 + Math.sin(angle) * r + 140 * fly ** 2}) rotate(${i * 41 + f * 8})`}
            />
          );
        })}
        <text
          x="480"
          y="363"
          textAnchor="middle"
          fontSize="100"
          fontWeight="900"
          fill={RED}
          opacity={1 - ease(f / 9)}
        >
          404
        </text>
      </g>
      {palette.map((color, i) => {
        const s = clamp(pop(f - 5 - i * 5));
        return (
          <g
            key={color}
            transform={`translate(${480 + (i - 1) * 238 * s} ${435 - (i === 1 ? 48 : 0) * s + Math.sin(f / 8 + i) * 9}) rotate(${(i - 1) * 15 * s}) scale(${Math.max(0.001, s)})`}
          >
            <rect
              x="-126"
              y="-164"
              width="252"
              height="361"
              rx="42"
              fill={color}
              opacity=".2"
            />
            <rect
              x="-126"
              y="-180"
              width="252"
              height="361"
              rx="42"
              fill={TINTS[color]}
              stroke={color}
              strokeWidth="6"
            />
            <circle r="77" fill={WHITE} />
            <g transform="scale(2.35)">{medallion(color, i)}</g>
          </g>
        );
      })}
    </>
  );
};

const Blank: React.FC<{ f: number; phrase: number }> = ({ f, phrase }) => {
  const t = ease((f - phrase + 10) / 12);
  return (
    <>
      <Stickman
        x={404}
        y={435}
        scale={1.13}
        pose="scratch_head"
        accentColor={BLUE}
        frame={f}
      />
      <g transform={`translate(250 ${120 + Math.sin(f / 8) * 6})`}>
        <path
          d="M84 10H440Q490 10 500 62Q541 89 520 139Q501 187 445 187H67Q12 187 12 139Q-15 115 7 81Q11 30 64 29Z"
          fill="#BFCFF6"
          transform="translate(0 12)"
        />
        <path
          d="M84 10H440Q490 10 500 62Q541 89 520 139Q501 187 445 187H67Q12 187 12 139Q-15 115 7 81Q11 30 64 29Z"
          fill="white"
          stroke={BLUE}
          strokeWidth="7"
        />
        <circle
          cx="154"
          cy="224"
          r="21"
          fill="white"
          stroke={BLUE}
          strokeWidth="6"
        />
        <circle
          cx="126"
          cy="266"
          r="12"
          fill="white"
          stroke={BLUE}
          strokeWidth="6"
        />
        {["A", "B", "?", "W", "Z", "…"].map((letter, i) => (
          <text
            key={letter}
            textAnchor="middle"
            fontWeight="900"
            fontSize={66 * (1 - t) + 1}
            fill={BLUE}
            opacity={1 - t}
            transform={`translate(${mix(63 + i * 78, 268, t)} ${mix(116 + (i % 2) * 27, 106, t) + Math.sin(f / 3 + i) * 6 * (1 - t)}) rotate(${(i - 2.5) * 10 * (1 - t)})`}
          >
            {letter}
          </text>
        ))}
        {t > 0 && t < 1 && (
          <circle cx="268" cy="100" r={9 * Math.sin(Math.PI * t)} fill={BLUE} />
        )}
      </g>
    </>
  );
};

const Example: React.FC<{ f: number }> = ({ f }) => (
  <>
    <Stickman
      x={258}
      y={435}
      scale={1.12}
      pose="scratch_head"
      accentColor={BLUE}
      frame={f}
    />
    <Stickman
      x={711}
      y={435}
      scale={1.12}
      pose="nod_heart"
      accentColor={BLUE}
      frame={f}
      flipX
    />
    <g
      transform={`translate(640 ${235 + Math.sin(f / 6) * 8}) scale(${Math.max(0.001, pop(f - 9))})`}
    >
      <path
        d={bubble}
        transform="translate(-133 -62) scale(.73)"
        fill={WHITE}
        stroke={BLUE}
        strokeWidth="8"
      />
      <path
        fill={BLUE}
        d="M0 42C-20 25 -55 3 -55 -23C-55 -55 -21 -63 0 -37C21 -63 55 -55 55 -23C55 3 20 25 0 42Z"
      />
    </g>
    <path
      d="M153 361l-30 -26m50 9 -15 -32"
      stroke={BLUE}
      strokeWidth="7"
      strokeLinecap="round"
      opacity=".75"
    />
  </>
);

const mystery = (f: number) => (
  <g
    transform={`translate(657 ${319 + Math.sin(f / 6) * 13}) rotate(${5 * Math.sin(f / 8)})`}
  >
    <rect
      x="-154"
      y="-155"
      width="308"
      height="308"
      rx="56"
      fill="#F4CD92"
      opacity=".42"
    />
    <rect
      x="-145"
      y="-156"
      width="290"
      height="290"
      rx="51"
      fill={WHITE}
      stroke={AMBER}
      strokeWidth="7"
      strokeDasharray="16 13"
    />
    <text
      x="0"
      y="57"
      textAnchor="middle"
      fontSize="179"
      fontWeight="900"
      fill={AMBER}
    >
      ?
    </text>
  </g>
);

const Weather: React.FC<{ f: number; umbrella: boolean }> = ({
  f,
  umbrella,
}) => {
  const flip = ease(f / 11);
  const open = Math.max(0.025, Math.min(1.08, pop(f)));
  return (
    <>
      {!umbrella && flip < 0.5 && (
        <g transform={`translate(0 ${-40 * flip})`} opacity={1 - 2 * flip}>
          {mystery(f)}
        </g>
      )}
      <g
        transform={`translate(480 ${202 + Math.sin(f / 8) * 5}) scale(${umbrella ? 0.78 : Math.max(0.001, 2 * flip - 1)} 1)`}
        opacity={umbrella ? 0.75 : clamp(2 * flip - 1)}
      >
        <path
          d="M-225 39Q-248 9 -225 -29Q-197 -66 -150 -54Q-130 -124 -55 -117Q5 -115 30 -62Q70 -124 146 -83Q174 -66 187 -33Q244 -37 251 11Q258 65 198 69H-181Q-207 67 -225 39Z"
          fill="#FFFDF8"
          stroke={AMBER}
          strokeWidth="8"
          strokeLinejoin="round"
        />
        <path
          d="M-146 37h102m29 0h41"
          stroke="#EAC484"
          strokeWidth="6"
          strokeLinecap="round"
        />
      </g>
      <g
        stroke="#657F9C"
        strokeWidth="6"
        strokeLinecap="round"
        opacity={umbrella ? 0.53 : clamp(2 * flip - 1) * 0.78}
      >
        {Array.from({ length: 27 }, (_, i) => {
          const x =
            (umbrella ? 190 : 260) + ((i * 67) % (umbrella ? 600 : 490));
          const y =
            291 +
            ((i * 37 + f * 14) % (umbrella && x > 254 && x < 705 ? 93 : 332));
          return (
            <path
              key={i}
              d={`M${x} ${y}l-15 31`}
              opacity={0.42 + (i % 5) * 0.12}
            />
          );
        })}
      </g>
      <Stickman
        x={480}
        y={478}
        scale={1.01}
        pose={umbrella ? "thumbs_up" : "rain_cover"}
        accentColor={AMBER}
        frame={f}
      />
      {umbrella && (
        <>
          <g
            transform={`translate(480 459) scale(${open} ${0.5 + open * 0.5})`}
            stroke={INK}
            strokeWidth="8"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M0 -118V75Q0 104 28 101Q51 100 51 76" fill="none" />
            <path
              d="M-250 -3Q-194 -137 0 -139Q185 -139 250 -3Q168 -34 93 8Q-1 -30 -91 8Q-176 -34 -250 -3Z"
              fill="#FFCB73"
            />
            <path
              d="M0 -139Q-85 -97 -91 8Q-1 -30 93 8Q88 -98 0 -139Z"
              fill="#E89B35"
            />
          </g>
          <Spark
            x={765}
            y={426}
            color={AMBER}
            scale={1.2 + 0.26 * Math.sin(f / 4)}
          />
          <Spark
            x={181}
            y={451}
            color={AMBER}
            scale={0.86 + 0.2 * Math.cos(f / 4)}
          />
        </>
      )}
    </>
  );
};

const Watch: React.FC<{ f: number }> = ({ f }) => (
  <>
    <Stickman
      x={280}
      y={428}
      scale={1.18}
      pose="one_finger"
      accentColor={GREEN}
      frame={f}
    />
    <g
      transform={`translate(670 ${392 + 10 * Math.sin(f / 9)}) scale(${0.74 + 0.26 * pop(f)})`}
    >
      <circle cy="13" r="143" fill="#B4DCCC" />
      <g stroke={GREEN} strokeWidth="8" strokeLinecap="round" fill={WHITE}>
        <path d="M0 -141v-57m-27 0h54M96 -107l29 -35" />
        <circle r="140" />
        {Array.from({ length: 12 }, (_, i) => (
          <path
            key={i}
            d="M0 -111v13"
            transform={`rotate(${i * 30})`}
            opacity={i % 3 ? 0.42 : 1}
          />
        ))}
        <path d="M0 14V-88" transform={`rotate(${f * 18})`} />
        <circle r="10" fill={GREEN} />
      </g>
      <g transform={`translate(112 133) scale(${1 + 0.08 * Math.sin(f / 4)})`}>
        <rect x="-65" y="-43" width="130" height="86" rx="34" fill={GREEN} />
        <text
          y="19"
          textAnchor="middle"
          fontSize="54"
          fontWeight="900"
          fill={WHITE}
        >
          1s
        </text>
      </g>
    </g>
  </>
);

const Compare: React.FC<{ f: number }> = ({ f }) => (
  <>
    <path d="M480 94V791" stroke={WHITE} strokeWidth="15" />
    {[RED, GREEN].map((color, i) => (
      <g key={color} transform={`translate(${i ? 500 : 40} 90)`}>
        <rect
          width="420"
          height="700"
          rx="49"
          fill={TINTS[color]}
          stroke={color}
          strokeWidth="2"
        />
        <rect x="24" y="54" width="372" height="106" rx="28" fill={WHITE} />
        <text
          x="210"
          y="121"
          textAnchor="middle"
          fontSize={i ? 35 : 49}
          fontWeight="900"
          fill={INK}
          transform={i ? undefined : `translate(${Math.sin(f * 1.52) * 4} 0)`}
        >
          {i ? "Give me a second" : "À... Ừm..."}
        </text>
        <Stickman
          pose={i ? "calm" : "sweat"}
          x={205}
          y={221}
          scale={1.02}
          accentColor={color}
          frame={f}
          flipX={!i}
        />
        <g
          transform={`translate(210 616) scale(${Math.max(0.001, pop(f - (i ? 17 : 0)))})`}
        >
          <circle r="48" fill={color} />
          <path
            d={i ? "M-22 0l15 16 29 -35" : "M-16 -16l32 32m0 -32 -32 32"}
            fill="none"
            stroke={WHITE}
            strokeWidth="8"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </g>
      </g>
    ))}
  </>
);

const Recap: React.FC<{ f: number; morph?: number }> = ({ f, morph = 0 }) => (
  <>
    {palette.map((color, i) => {
      const s =
        0.93 +
        0.07 * pop(f - i * 6) +
        0.06 * Math.exp(-(((f - i * 18 - 4) / 5) ** 2));
      return (
        <g
          key={color}
          opacity={1 - ease((morph - 0.51) / 0.45)}
          transform={`translate(${mix(480, 264, morph)} ${mix(221 + i * 222, 205, morph)}) scale(${s * (1 - morph * 0.61)} ${s * (1 - morph * 0.67)})`}
        >
          <rect
            x="-394"
            y="-82"
            width="788"
            height="172"
            rx="42"
            fill={color}
            opacity=".16"
          />
          <rect
            x="-394"
            y="-92"
            width="788"
            height="172"
            rx="42"
            fill={TINTS[color]}
            stroke={color}
            strokeWidth="4"
          />
          <circle cx="-303" cy="-6" r="55" fill={WHITE} />
          <g transform="translate(-303 -6) scale(1.41)">
            {medallion(color, i)}
          </g>
          <text x="-220" y="13" fontWeight="900" fontSize="47" fill={INK}>
            {i + 1}. {phraseList[i]}
          </text>
        </g>
      );
    })}
  </>
);

export const Stage: React.FC<{
  id: number;
  f: number;
  length: number;
  color: string;
  phrase: number;
}> = ({ id, f, length, color, phrase }) => {
  const join = ease((f - length + 20) / 19);
  const intro = id === 11 ? 1 - join : 1;
  return (
    <svg
      width="960"
      height="900"
      viewBox="0 0 960 900"
      style={{ display: "block", overflow: "hidden" }}
    >
      <defs>
        <pattern
          id="stage-grid"
          width="32"
          height="32"
          patternUnits="userSpaceOnUse"
        >
          <circle
            cx="2"
            cy="2"
            r="1.65"
            fill={id === 11 ? RED : color}
            opacity=".29"
          />
        </pattern>
        <clipPath id="stage-frame">
          <rect x="0" y="0" width="960" height="900" rx="65" />
        </clipPath>
      </defs>
      <g clipPath="url(#stage-frame)">
        <rect
          width="960"
          height="900"
          fill={id === 11 ? TINTS[RED] : TINTS[color]}
        />
        {id === 11 && (
          <rect width="960" height="900" fill={TINTS[GREEN]} opacity={intro} />
        )}
        <rect width="960" height="900" fill="url(#stage-grid)" />
        {!!(id < 9 || id === 11) && (
          <ellipse
            cx="480"
            cy="494"
            rx="399"
            ry="383"
            fill={WHITE}
            opacity=".52"
          />
        )}
        {id === 1 && <Hook f={f} />}
        {id === 2 && <Crash f={f} />}
        {id === 3 && <Blank f={f} phrase={phrase} />}
        {id === 4 && <Example f={f} />}
        {id === 5 && (
          <>
            <Stickman
              x={285}
              y={421}
              scale={1.19}
              pose="point"
              accentColor={AMBER}
              frame={f}
            />
            {mystery(f)}
          </>
        )}
        {id === 6 && <Weather f={f} umbrella={false} />}
        {id === 7 && <Weather f={f} umbrella />}
        {id === 8 && <Watch f={f} />}
        {id === 9 && <Compare f={f} />}
        {id === 10 && <Recap f={f} />}
        {id === 11 && (
          <>
            <Recap f={56 + f} morph={join} />
            <Hook f={0} opacity={ease((join - 0.36) / 0.64)} />
            <g
              opacity={intro}
              transform={`translate(836 ${121 + Math.sin(f / 4) * 14}) scale(${1.33 * pop(f)})`}
            >
              <circle r="44" fill={WHITE} />
              <Bookmark />
            </g>
          </>
        )}
      </g>
      <rect
        x="2"
        y="2"
        width="956"
        height="896"
        rx="64"
        fill="none"
        stroke={INK}
        strokeOpacity=".095"
        strokeWidth="4"
      />
    </svg>
  );
};
