import React from "react";

export type Pose =
  | "idle"
  | "frozen_404"
  | "scratch_head"
  | "point"
  | "rain_cover"
  | "thumbs_up"
  | "one_finger"
  | "sweat"
  | "calm"
  | "nod_heart";

type Props = {
  pose: Pose;
  accentColor: string;
  flipX?: boolean;
  frame: number;
  x: number;
  y: number;
  scale?: number;
};

const arms: Record<Pose, string> = {
  idle: "M0 151 Q-35 181 -62 192 L-88 171 M0 151 Q42 177 65 166 L96 125",
  frozen_404: "M0 151 L-63 195 -89 244 M0 151 L63 195 89 244",
  scratch_head: "M0 151 Q-38 174 -55 205 L-39 235 M0 151 Q65 165 78 124 L65 70",
  point: "M0 151 Q-38 174 -50 207 L-33 229 M0 151 L65 147 108 117 128 113",
  rain_cover:
    "M0 151 Q-68 157 -92 103 L-74 52 -24 22 M0 151 Q68 157 92 103 L74 52 24 22",
  thumbs_up: "M0 151 Q-45 172 -62 208 L-37 224 M0 151 Q45 188 76 165 L93 128",
  one_finger: "M0 151 Q-45 183 -62 213 L-36 228 M0 151 Q54 183 83 149 L96 112",
  sweat: "M0 151 Q-42 172 -67 223 L-41 215 M0 151 Q40 173 66 214 L45 229",
  calm: "M0 151 Q-35 176 -45 206 L-24 219 M0 151 Q37 174 53 195 L86 172",
  nod_heart: "M0 151 Q-36 177 -52 215 L-33 230 M0 151 Q44 175 62 199 L86 178",
};

export const Stickman: React.FC<Props> = ({
  pose,
  accentColor,
  flipX,
  frame,
  x,
  y,
  scale = 1,
}) => {
  const stiff = pose === "frozen_404";
  const bob = stiff ? 0 : 3.5 * Math.sin(frame / 8);
  const tilt = stiff
    ? -5
    : pose === "nod_heart"
      ? 7 * Math.sin(frame / 5)
      : 4 * Math.sin(frame / 10);
  const sweat = pose === "sweat" || stiff;
  const nextDrop = (frame % 22) / 22;
  const blink = !stiff && frame % 43 >= 40;
  return (
    <g transform={`translate(${x} ${y}) scale(${scale})`}>
      <ellipse
        cx="0"
        cy="333"
        rx={120 - bob}
        ry="15"
        fill={accentColor}
        opacity=".16"
      />
      <g
        transform={`translate(0 ${bob}) scale(${flipX ? -1 : 1} 1)`}
        stroke="#1D1D1F"
        strokeWidth="9"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
      >
        <path d="M0 118 Q-6 168 0 229 M0 229 Q-30 269 -55 316 H-80 M0 229 Q37 268 56 316 H80" />
        <path
          d={arms[pose]}
          transform={
            pose === "idle" || pose === "point"
              ? `rotate(${3 * Math.sin(frame / 5)} 0 151)`
              : undefined
          }
        />
        {pose === "thumbs_up" && (
          <path
            fill="#FFFDF8"
            d="M86 132Q77 121 86 114L95 109 101 93Q111 89 113 99L111 111 126 113Q134 117 130 128L125 140Q112 147 92 140Z"
          />
        )}
        {pose === "one_finger" && (
          <path
            fill="#FFFDF8"
            d="M86 114Q79 104 88 98L97 95 100 70Q105 60 112 69L112 98Q130 98 127 113L120 127Q101 136 88 123Z"
          />
        )}
        <g transform={`rotate(${tilt} 0 113)`}>
          <circle cy="64" r="59" fill="#FFFDF8" />
          {stiff ? (
            <g transform="rotate(7 0 64)">
              <rect
                x="-78"
                y="27"
                width="156"
                height="76"
                rx="17"
                fill="#E63946"
                stroke="none"
              />
              <text
                x="0"
                y="82"
                textAnchor="middle"
                fill="white"
                stroke="none"
                fontSize="55"
                fontWeight="900"
                transform={flipX ? "scale(-1 1)" : undefined}
              >
                404
              </text>
            </g>
          ) : (
            <>
              <path
                d={blink ? "M-12 56h9 M28 56h9" : "M-7 51v6 M33 51v6"}
                strokeWidth="8"
              />
              <path
                d={
                  pose === "sweat"
                    ? "M-7 87 Q12 68 28 84"
                    : "M-6 76 Q13 96 32 74"
                }
                strokeWidth="6"
              />
              <circle
                cx="-32"
                cy="74"
                r="8"
                fill={accentColor}
                opacity=".33"
                stroke="none"
              />
              <path
                d="M-22 7 Q3 -8 23 15"
                stroke={accentColor}
                strokeWidth="8"
              />
            </>
          )}
        </g>
        {sweat && (
          <path
            d="M0 -15 Q-18 6 -12 14 Q0 30 12 14 Q18 6 0 -15Z"
            transform={`translate(-93 ${53 + nextDrop * 80})`}
            fill={stiff ? "#E63946" : "#2563EB"}
            stroke="none"
            opacity={1 - nextDrop}
          />
        )}
      </g>
    </g>
  );
};
