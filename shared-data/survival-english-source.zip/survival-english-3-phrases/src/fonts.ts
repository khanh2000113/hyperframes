import { getInfo } from "@remotion/google-fonts/BeVietnamPro";
import { loadFonts } from "@remotion/google-fonts/base";
import { staticFile } from "remotion";

const weights = ["600", "800", "900"];
const subsets = ["latin", "latin-ext", "vietnamese"];
const meta = getInfo();

// Keep the Google Fonts metadata and Unicode ranges, serving local copies of the font files.
export const { fontFamily } = loadFonts(
  {
    ...meta,
    fonts: {
      normal: Object.fromEntries(
        weights.map((weight) => [
          weight,
          Object.fromEntries(
            subsets.map((subset) => [
              subset,
              staticFile(
                `fonts/be-vietnam-pro-${subset}-${weight}-normal.woff2`,
              ),
            ]),
          ),
        ]),
      ),
    },
  },
  "normal",
  { weights, subsets, ignoreTooManyRequestsWarning: true },
);
