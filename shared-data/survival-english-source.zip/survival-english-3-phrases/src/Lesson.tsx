import React from "react";
import {
  AbsoluteFill,
  Audio,
  Sequence,
  staticFile,
  useCurrentFrame,
} from "remotion";
import {
  AMBER,
  BLUE,
  Bookmark,
  clamp,
  ease,
  GREEN,
  INK,
  PAPER,
  pop,
  RED,
  Stage,
  TINTS,
} from "./components/Stage";
import { fontFamily } from "./fonts";
import timeline from "./data/timeline.json";

type Beat = (typeof timeline.beats)[number];
const colors = [
  RED,
  RED,
  BLUE,
  BLUE,
  AMBER,
  AMBER,
  AMBER,
  GREEN,
  GREEN,
  GREEN,
  GREEN,
];
const letters = { fontWeight: 900, letterSpacing: "-.065em", lineHeight: 1.06 };
const hookLabel = "ĐỨNG HÌNH?";

const Progress: React.FC<{ beat: Beat; f: number; color: string }> = ({
  beat,
  f,
  color,
}) => {
  const id = beat.id;
  if (id === 1) return null;
  const chapter = id === 2 ? 1 : id < 5 ? 2 : id < 8 ? 3 : 4;
  const from = [2, 3, 5, 8][chapter - 1];
  const to = [2, 4, 7, 11][chapter - 1];
  const first = timeline.beats[from - 1].startFrame;
  const last =
    timeline.beats[to - 1].startFrame + timeline.beats[to - 1].durationInFrames;
  const current = (beat.startFrame + f - first) / (last - first - 1);
  const intro = id === 2 ? clamp(pop(f)) : 1;
  const outro = id === 11 ? 1 - ease((f - beat.durationInFrames + 20) / 18) : 1;
  return (
    <div
      data-zone="progress"
      style={{
        position: "absolute",
        top: 125,
        left: 360,
        width: 360,
        height: 76,
        borderRadius: 42,
        background: "#FFFDF8",
        border: "2px solid #DBD4CA",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        gap: 22,
        opacity: intro * outro,
        transform: `translateY(${-28 * (1 - intro)}px)`,
        boxShadow: "0 6px 0 #1D1D1F09",
      }}
    >
      <span
        style={{
          fontSize: 28,
          fontWeight: 900,
          fontVariantNumeric: "tabular-nums",
          letterSpacing: "-.05em",
        }}
      >
        {String(chapter).padStart(2, "0")}
        <span style={{ color: "#756E65" }}>/04</span>
      </span>
      <div
        style={{
          width: 174,
          height: 13,
          borderRadius: 99,
          background: "#EEE8DE",
          overflow: "hidden",
        }}
      >
        <div
          style={{
            height: "100%",
            width: `${12 + 88 * clamp(current)}%`,
            background: color,
            borderRadius: 99,
          }}
        />
      </div>
    </div>
  );
};

const Pill: React.FC<{
  children: React.ReactNode;
  color: string;
  f: number;
  large?: boolean;
  highlighted?: boolean;
}> = ({ children, color, f, large, highlighted }) => (
  <div
    style={{
      alignSelf: "center",
      display: "inline-flex",
      alignItems: "center",
      gap: 25,
      borderRadius: 99,
      padding: large ? "18px 36px" : "15px 30px",
      fontSize: large ? 62 : 37,
      background: TINTS[color],
      color: INK,
      whiteSpace: "nowrap",
      fontWeight: highlighted || large ? 900 : 800,
      border: `3px solid ${color}`,
      boxShadow: `0 0 0 ${5 + 3 * Math.sin(f / 8)}px ${TINTS[color]}70`,
      transform: `translateY(${16 * (1 - pop(f))}px)`,
      opacity: clamp(pop(f)),
      lineHeight: 1.08,
      letterSpacing: large ? "-.06em" : "-.038em",
    }}
  >
    {children}
  </div>
);

const Kinetic: React.FC<{
  lines: string[];
  size: number;
  color: string;
  f: number;
  beat: Beat;
  move?: "side" | "down";
  outline?: boolean;
}> = ({ lines, size, color, f, beat, move, outline }) => {
  const speech = beat.segments[beat.segments.length - 1];
  let index = 0;
  return (
    <div style={letters}>
      {lines.map((line) => (
        <div key={line} style={{ whiteSpace: "nowrap", fontSize: size }}>
          {line.split(" ").map((word, i) => {
            const position = index++;
            const matching = speech.words.find(
              (w) =>
                w.text.toLowerCase().replace(/[^a-z]/g, "") ===
                word.toLowerCase().replace(/[^a-z]/g, ""),
            );
            const at = matching
              ? speech.startFrame + matching.frame
              : position * 3;
            const p = pop(f - at);
            const tint =
              lines.length === 1 || line === lines.at(-1) ? color : INK;
            const hollow =
              outline && word === "BLANK" ? ease((f - at - 1) / 8) : 0;
            const enter = clamp(pop(f - 2 - position));
            return (
              <React.Fragment key={position}>
                {i > 0 ? " " : null}
                <span
                  style={{
                    display: "inline-block",
                    opacity: 0.56 + 0.44 * clamp(p),
                    color: hollow >= 0.95 ? "transparent" : tint,
                    WebkitTextStroke: hollow
                      ? `${3.4 * hollow}px ${color}`
                      : undefined,
                    transform: `translate(${move === "side" ? -43 * (1 - enter) : 0}px,${(move === "down" ? -23 : 13) * (1 - enter) - 12 * Math.max(0, p - 1)}px) scale(${0.93 + 0.065 * enter + 0.62 * Math.max(0, p - 1)})`,
                  }}
                >
                  {word}
                </span>
              </React.Fragment>
            );
          })}
        </div>
      ))}
    </div>
  );
};

const Copy: React.FC<{ beat: Beat; f: number; color: string }> = ({
  beat,
  f,
  color,
}) => {
  const id = beat.id;
  const transition = ease((f - beat.durationInFrames + 20) / 19);
  const header = (text: string, size: number, tint = color, motion = f) => (
    <div
      style={{
        ...letters,
        color: tint,
        fontSize: size,
        whiteSpace: "nowrap",
        transform: `scale(${0.89 + 0.11 * pop(motion)})`,
      }}
    >
      {text}
    </div>
  );
  const hook = (motion: number) => header(hookLabel, 137, RED, motion);
  return (
    <div
      data-zone="typography"
      style={{
        position: "absolute",
        left: 48,
        right: 48,
        top: 1200,
        height: 340,
        overflow: "hidden",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        gap: 22,
        textAlign: "center",
      }}
    >
      {id === 1 && hook(f)}
      {id === 2 && (
        <>
          {header("3 CÂU", 103, INK)}
          {header("CỨU MẠNG", 124, RED, f - 4)}
        </>
      )}
      {id === 3 && (
        <Kinetic
          lines={["MY MIND", "WENT BLANK"]}
          size={126}
          color={color}
          f={f}
          beat={beat}
          outline
        />
      )}
      {id === 4 && (
        <>
          {header("My mind went blank", 86, BLUE)}
          <Pill color={color} f={f - 8}>
            Đầu tôi tự dưng trống rỗng
          </Pill>
        </>
      )}
      {id === 5 && (
        <Kinetic
          lines={["WHAT DO YOU", "CALL...?"]}
          size={115}
          color={color}
          f={f}
          beat={beat}
          move="down"
        />
      )}
      {id === 6 && (
        <>
          <Kinetic
            lines={["What do you call"]}
            size={95}
            color={INK}
            f={f}
            beat={beat}
          />
          <Pill
            color={color}
            f={
              f -
              (beat.segments[0].words.find(
                (w) => w.text.toLowerCase() === "the",
              )?.frame ?? 21)
            }
            highlighted
            large
          >
            the thing for rain?
          </Pill>
        </>
      )}
      {id === 7 && (
        <div
          style={{
            filter: `drop-shadow(0 0 ${10 + 8 * Math.sin(f / 6)}px #F6AF42AA)`,
          }}
        >
          {header("UMBRELLA!", 138, AMBER)}
        </div>
      )}
      {id === 8 && (
        <Kinetic
          lines={["GIVE ME", "A SECOND"]}
          size={125}
          color={color}
          f={f}
          beat={beat}
          move="side"
        />
      )}
      {id === 9 && (
        <Pill color={color} f={f} large>
          Tự nhiên hơn hẳn
        </Pill>
      )}
      {id === 10 && (
        <>
          {header("3 PHAO", 108, INK)}
          {header("CỨU SINH", 125, GREEN, f - 5)}
        </>
      )}
      {id === 11 && (
        <>
          <div
            style={{
              position: "absolute",
              width: "100%",
              display: "flex",
              justifyContent: "center",
              opacity: 1 - ease(transition / 0.48),
            }}
          >
            <Pill color={GREEN} f={f} large>
              Lưu lại dùng dần nhé
              <svg width="43" height="52" viewBox="-27 -29 54 60">
                <Bookmark />
              </svg>
            </Pill>
          </div>
          <div
            style={{
              position: "absolute",
              opacity: ease((transition - 0.52) / 0.48),
            }}
          >
            {hook(0)}
          </div>
        </>
      )}
    </div>
  );
};

export const LessonArt: React.FC<{ frame: number }> = ({ frame }) => {
  const beat =
    timeline.beats.find((b) => frame < b.startFrame + b.durationInFrames) ??
    timeline.beats.at(-1)!;
  const f = frame - beat.startFrame;
  const color = colors[beat.id - 1];
  return (
    <AbsoluteFill style={{ background: PAPER, color: INK, fontFamily }}>
      <div
        aria-hidden
        style={{
          position: "absolute",
          inset: 0,
          opacity: 0.03,
          backgroundImage: `url(${staticFile("paper-grain.png")})`,
          pointerEvents: "none",
        }}
      />
      <Progress beat={beat} f={f} color={color} />
      <div
        data-zone="stage"
        style={{
          position: "absolute",
          left: 60,
          top: 280,
          width: 960,
          height: 900,
          overflow: "hidden",
        }}
      >
        <Stage
          id={beat.id}
          f={f}
          length={beat.durationInFrames}
          color={color}
          phrase={beat.segments.at(-1)!.startFrame}
        />
      </div>
      <Copy beat={beat} f={f} color={color} />
    </AbsoluteFill>
  );
};

export const SurvivalEnglish3Phrases: React.FC = () => {
  const frame = useCurrentFrame();
  const drop = timeline.beats[1].startFrame;
  return (
    <>
      <LessonArt frame={frame} />
      <Sequence
        from={drop}
        durationInFrames={timeline.durationInFrames - drop}
        name="115 BPM marimba"
      >
        <Audio
          src={staticFile("sfx/bg_bed.wav")}
          volume={(f) =>
            10 ** (-22 / 20) *
            Math.min(1, f / 3) *
            clamp((timeline.durationInFrames - drop - f - 4) / 11)
          }
        />
      </Sequence>
      {timeline.beats.map((beat) => (
        <Sequence
          key={beat.id}
          from={beat.startFrame}
          durationInFrames={beat.durationInFrames}
          name={`Beat ${beat.id}`}
        >
          {beat.segments.map((segment) => (
            <Sequence
              key={segment.file}
              from={segment.startFrame}
              durationInFrames={segment.durationInFrames}
            >
              <Audio src={staticFile(segment.file)} volume={0.91} />
            </Sequence>
          ))}
          {beat.cues.map((cue) => (
            <Sequence key={`${cue.file}-${cue.frame}`} from={cue.frame}>
              <Audio
                src={staticFile(cue.file)}
                volume={cue.volume}
                playbackRate={cue.rate}
              />
            </Sequence>
          ))}
        </Sequence>
      ))}
    </>
  );
};
