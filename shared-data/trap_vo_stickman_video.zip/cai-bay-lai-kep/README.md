# CÁI BẪY CỦA LÃI KÉP

Dự án Remotion gốc • 1080 × 1920 (9:16) • 30 fps • 780 frame / 26 giây.
Kinetic Typography, stickman SVG 2D, font Be Vietnam Pro đi kèm để hiển thị tiếng Việt offline.

## Mở và chỉnh sửa

Yêu cầu Node.js 22+ và npm. Giải nén, mở terminal tại thư mục chứa `package.json`:

```sh
npm ci
npm start
```

Mở URL Remotion Studio được in ra terminal, chọn composition **CompoundTrap**.
`npm run typecheck` kiểm tra TypeScript. `npm run bundle:check` chỉ đóng gói web để kiểm tra.
Không có script render video, không có hook tự động xuất MP4; dự án bàn giao không chứa MP4.
`node_modules` và build cache không nằm trong ZIP; `package-lock.json` khóa phiên bản dependencies.

## Bốn track độc lập

Trong cây timeline Remotion Studio có bốn Sequence cấp cao:

| Track | Nội dung | Vị trí mã nguồn |
|---|---|---|
| Visuals | Stickman, hóa đơn, biểu đồ, puzzle, app nợ, bookmark | `src/Film.tsx` / SceneOne…Four |
| Captions | Chữ động, tiêu đề, CTA | `src/Film.tsx` / Kinetic |
| Voice-over | 6 cue giọng đọc, hiện đang im lặng | `timeline.json` |
| SFX | 14 cue âm thanh, hiện đang im lặng | `timeline.json` |

Các Sequence cue vẫn được khai báo khi chưa có audio. Bật prop `showTimingGuides` thành `true` trong Studio hoặc `src/Root.tsx` để thấy nhãn cue khi preview; mặc định tắt để không che thiết kế. Với cue chồng nhau, xem đủ tên/thời gian trên timeline hoặc trong CSV.

`timeline.json` là nguồn thời gian dùng trực tiếp bởi composition; `docs/timeline.csv` là bản tra cứu được xuất từ cùng dữ liệu. Các mốc tính theo frame ở 30 fps, điểm cuối **không bao gồm** trong clip. VO/SFX có `source: null`, không tải file giả và không tạo tiếng.

Đây là dự án Remotion cùng manifest timeline chung. Môi trường tạo dự án không có công cụ local **video-shotcraft**, nên chưa kiểm thử import và không khẳng định JSON là định dạng native của công cụ đó. Nếu công cụ nhận entry Remotion, dùng `src/index.ts`, composition `CompoundTrap`; khi chuyển đổi timeline, lấy mốc trong JSON/CSV. Không có file project native shotcraft giả.

## Gắn giọng đọc / SFX

1. Đặt audio thật vào `public/audio/`, ví dụ `vo-01.wav`.
2. Trong `timeline.json`, tìm cue `vo-01`, đổi `source` từ `null` thành `"audio/vo-01.wav"`.
3. Điều chỉnh `gain` theo nhu cầu. Giọng đọc mặc định 1.0, SFX 0.45.
4. Audio bắt đầu từ đầu file tại `from`; Sequence giới hạn phát trong `durationInFrames`. Chuẩn bị file có độ dài vừa cue, thêm fade ngay trong file nếu cần. Độ dài file ngắn hơn cue sẽ để khoảng trống ở cuối.
5. Chạy preview và nghe lại để căn giọng đọc thực tế. Kịch bản VO là đề xuất; chưa có thu âm/TTS.

## Phân cảnh / chuyển động

- **0–4s (0–119):** Tăng trưởng xanh bên trái, stickman cầm gậy. Hóa đơn đỏ rơi bên phải ở 2.1s; nhân vật giật mình và gậy rơi sau đó.
- **4–12s (120–359):** Tiêu đề bốn cạm bẫy. Các puzzle lần lượt va vào nhau: Thẻ tín dụng, Phí ẩn, Nợ quá hạn, Vay chồng vay. Nhân vật diễn thuyết, rồi ôm đầu.
- **12–20s (360–599):** App nợ đếm từ 10 lên 30 triệu; chữ “→ 30 Triệu!” bật scale và màu đỏ neon. Stickman cố chống đỡ đẩy con số lên và bị ép dẹt khi đạt 30.
- **20–26s (600–779):** Nhân vật đứng dậy chỉ bookmark nhấp nháy vàng. CTA “LƯU LẠI video này ngay!”.

Chuyển động phụ thuộc `useCurrentFrame`, `interpolate`, `spring`; không dùng timer, CSS animation hay số ngẫu nhiên, nên tua/seek ổn định. Cắt cảnh tại các mốc đã yêu cầu. Chữ captions độc lập với đồ họa; caption nền khung (footer/tag) không phải phụ đề giọng đọc tự động.

## Ghi chú nội dung

10 → 30 triệu là tình huống minh họa, không phải phép tính tài chính cho một lãi suất hoặc thời hạn xác định. Cảnh 3 có chú thích trên màn hình. Chủ đề mô tả tác động của lãi và phí lên nợ; tránh hiểu thành cam kết rằng mọi khoản nợ 10 triệu sẽ thành 30 triệu.

## Tài nguyên

`public/assets/`: `growth.svg`, `bill.svg`, `bookmark.svg`, `stickman.svg`, font TTF và giấy phép OFL. Stickman động được vẽ trực tiếp trong `src/components/Stickman.tsx` để thay đổi khớp tay chân. Các SVG do dự án tự vẽ, không có ảnh hoặc audio bên ngoài cần tải thêm khi preview.

Kiểm tra kỹ thuật thực tế được ghi ở `docs/verification.md`.

`docs/storyboard.jpg` là contact sheet 8 khung hình kiểm tra, không phải video.
