Audio intentionally absent. Set source to a public-relative path such as audio/vo-01.wav in timeline.json after copying real audio here. No empty WAV files are used.
