# Kiểm tra bàn giao

- TypeScript: `npm run typecheck` — PASS.
- Web bundle: `npm run bundle:check` — PASS.
- Composition được Chromium/Remotion đọc: CompoundTrap, 1080 × 1920, 30 fps, 780 frame.
- 8 PNG ảnh tĩnh tại frame 40, 100, 155, 280, 410, 515, 640, 725 — tạo thành công.
- Đã xem contact sheet và kiểm tra lại cảnh gậy chỉ biểu đồ, cảnh app ép stickman; không phát hiện chữ bị tràn khung ở các ảnh mẫu.
- Timeline: đủ 4 track; Visuals/Captions cùng mốc 0, 120, 360, 600; kết thúc ở frame 780.
- 6 cue VO, 14 cue SFX; mọi cue có độ dài dương và nằm trong 0–780.
- VO/SFX vẫn `source: null`; chưa kiểm tra nghe vì chưa có file audio thật.
- Không kiểm thử import vào video-shotcraft do công cụ không có trong môi trường.
- Không chạy renderMedia, không encode video, không tạo MP4. Chỉ web bundle và ảnh tĩnh dùng để kiểm tra.
- Xem `storyboard.jpg` cho ảnh kiểm tra; đây là các thời điểm mẫu, không phải mọi frame.
