import data from '../timeline.json';
export const timeline = data;
