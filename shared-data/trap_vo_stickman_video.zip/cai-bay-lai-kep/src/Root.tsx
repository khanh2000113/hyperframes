import React from 'react';
import {Composition} from 'remotion';
import {Film} from './Film';
export const Root: React.FC = () => <Composition id="CompoundTrap" component={Film} durationInFrames={780} fps={30} width={1080} height={1920} defaultProps={{showTimingGuides:false}} />;
